This is a portal to manage Hostel Services and Housekeeping Services of a University environment. The tech stack used for the implementation is:
HTML5: markup language used for frontend web page structuring.
CSS3: used for styling the web pages.
Bootstrap 5.3.2: using pre-built UI components in the styling from Bootstrap for responsive design.
Python Flask: for the backend, for routing and query parameter handling.
Sqlite3: tabular data storage through file based database, since the requirements were lightweight.