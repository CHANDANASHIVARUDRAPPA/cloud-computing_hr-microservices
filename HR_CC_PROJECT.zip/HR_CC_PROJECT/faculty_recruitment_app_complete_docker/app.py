from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from flask_mysqldb import MySQL
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required
from werkzeug.utils import secure_filename
from datetime import datetime
import os
from flask import jsonify

app = Flask(__name__)
app.secret_key = 'cloudcomputing'

# These will now be injected via environment variables in Compose:
app.config['MYSQL_USER']     = os.environ['MYSQL_USER']
app.config['MYSQL_PASSWORD'] = os.environ['MYSQL_PASSWORD']
app.config['MYSQL_HOST']     = os.environ.get('MYSQL_HOST', 'db')
app.config['MYSQL_DB']       = os.environ['MYSQL_DB']

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

mysql = MySQL(app)

# Admin login setup
login_manager = LoginManager()
login_manager.init_app(app)

class Admin(UserMixin):
    def __init__(self, id):
        self.id = id

@login_manager.user_loader
def load_user(user_id):
    return Admin(user_id)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/user')
def user_dashboard():
    return render_template('user_dashboard.html')

@app.route('/apply')
def apply():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, title FROM jobs")
    jobs = cur.fetchall()
    cur.close()
    return render_template('apply.html', jobs=jobs)

@app.route('/submit_application', methods=['POST'])
def submit_application():
    data = request.form
    resume = request.files['resume']
    job_id = request.form['job_id']
    filename = secure_filename(resume.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    resume.save(filepath)

    status = 'Pending'
    experience = int(data['experience'])
    if experience >= 3 and any(kw in data['skills'].lower() for kw in ['phd', 'ai', 'machine learning']):
        status = 'Accepted'

    cur = mysql.connection.cursor()
    cur.execute("""
        INSERT INTO candidates (name, email, phone, resume, skills, experience, status, applied_on, job_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), %s)
    """, (data['name'], data['email'], data['phone'], filepath, data['skills'], data['experience'], status, job_id))
    mysql.connection.commit()
    cur.close()

    flash("Application submitted successfully!", "success")
    return redirect(url_for('apply'))

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form['username'] == 'admin' and request.form['password'] == 'admin123':
            login_user(Admin(1))
            return redirect(url_for('admin_dashboard'))
        flash("Invalid credentials!", "danger")
    return render_template('admin_login.html')

@app.route('/admin_dashboard')
@login_required
def admin_dashboard():
    cur = mysql.connection.cursor()

    # Fetch candidates with job titles
    cur.execute("""
        SELECT c.id, c.name, c.skills, c.experience, c.resume, c.status, j.title 
        FROM candidates c 
        LEFT JOIN jobs j ON c.job_id = j.id
    """)
    candidates = cur.fetchall()

    # Application status count
    cur.execute("SELECT status, COUNT(*) FROM candidates GROUP BY status")
    stats = cur.fetchall()

    # Applications per job/subject
    cur.execute("""
        SELECT j.title, COUNT(*) 
        FROM candidates c 
        LEFT JOIN jobs j ON c.job_id = j.id 
        GROUP BY j.title
    """)
    applications_per_job = cur.fetchall()

    cur.close()

    return render_template(
        'dashboard.html',
        candidates=candidates,
        stats=stats,
        applications_per_job=applications_per_job
    )

@app.route('/update_status/<int:id>/<string:status>')
@login_required
def update_status(id, status):
    cur = mysql.connection.cursor()
    cur.execute("UPDATE candidates SET status = %s WHERE id = %s", (status, id))
    mysql.connection.commit()
    cur.close()
    flash(f"Candidate has been {status} ", "info")
    return redirect(url_for('admin_dashboard'))

@app.route('/schedule_interview/<int:candidate_id>', methods=['GET', 'POST'])
def schedule_interview(candidate_id):
    if request.method == 'POST':
        interview_date = request.form['interview_date']
        panel = request.form['panel']
        link = request.form['link']
        message = request.form['message']
        interview_date = datetime.strptime(interview_date, '%Y-%m-%dT%H:%M')

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM interviews WHERE candidate_id=%s", [candidate_id])
        existing = cursor.fetchone()

        if existing:
            cursor.execute("""
                UPDATE interviews 
                SET interview_date=%s, panel=%s, link=%s, message=%s 
                WHERE candidate_id=%s
            """, (interview_date, panel, link, message, candidate_id))
        else:
            cursor.execute("""
                INSERT INTO interviews (candidate_id, interview_date, panel, link, message) 
                VALUES (%s, %s, %s, %s, %s)
            """, (candidate_id, interview_date, panel, link, message))

        mysql.connection.commit()
        cursor.close()
        flash('Interview scheduled successfully!', 'success')
        return redirect(url_for('admin_dashboard'))

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM candidates WHERE id=%s", (candidate_id,))
    candidate = cursor.fetchone()
    cursor.close()
    return render_template('schedule_interview.html', candidate=candidate)

@app.route('/view_resume/<path:filename>')
def view_resume(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/check_status', methods=['GET', 'POST'])
def check_status():
    if request.method == 'POST':
        email = request.form.get('email')
        
        # Ensure email is provided
        if not email:
            flash("Please provide an email address.", "warning")
            return render_template('check_status.html')

        try:
            cur = mysql.connection.cursor()
            cur.execute("SELECT id, name, status FROM candidates WHERE email=%s", [email])
            candidate = cur.fetchone()  # (id, name, status)

            interview = None
            if candidate and candidate[2] == 'Accepted':
                cur.execute("SELECT * FROM interviews WHERE candidate_id = %s", [candidate[0]])
                interview = cur.fetchone()
            cur.close()

            if candidate:
                return render_template('user_status.html',
                                       name=candidate[1],
                                       status=candidate[2],
                                       interview=interview)
            else:
                flash("No application found with the given email.", "danger")
                return render_template('check_status.html')  # ✅ FIX: ensure this return is present

        except Exception as e:
            flash(f"Error: {str(e)}", "danger")
            return render_template('check_status.html')

    # For GET request or when no form is submitted, render the form
    return render_template('check_status.html')



@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('admin_login'))


# --- JOB LISTINGS ---
@app.route('/api/jobs', methods=['GET'])
def get_jobs():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, title FROM jobs")
    jobs = cur.fetchall()
    cur.close()
    return jsonify([{'id': j[0], 'title': j[1]} for j in jobs])


# --- APPLY FOR JOB ---
@app.route('/api/candidates/apply', methods=['POST'])
def api_apply():
    data = request.form
    resume = request.files['resume']
    filename = secure_filename(resume.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    resume.save(filepath)

    experience = int(data['experience'])
    status = 'Accepted' if experience >= 3 and any(kw in data['skills'].lower() for kw in ['phd', 'ai', 'machine learning']) else 'Pending'

    cur = mysql.connection.cursor()
    cur.execute("""
        INSERT INTO candidates (name, email, phone, resume, skills, experience, status, applied_on, job_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), %s)
    """, (data['name'], data['email'], data['phone'], filepath, data['skills'], experience, status, data['job_id']))
    mysql.connection.commit()
    cur.close()

    return jsonify({'message': 'Application submitted successfully', 'status': status})


# --- GET CANDIDATE INFO ---
@app.route('/api/candidates/<int:id>', methods=['GET'])
def get_candidate(id):
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT c.name, c.skills, c.status, j.title 
        FROM candidates c 
        LEFT JOIN jobs j ON c.job_id = j.id 
        WHERE c.id = %s
    """, (id,))
    result = cur.fetchone()
    cur.close()
    if result:
        name, skills, status, job_title = result
        return jsonify({'name': name, 'skills': skills, 'status': status, 'job_title': job_title})
    return jsonify({'error': 'Candidate not found'}), 404


# --- UPDATE STATUS ---
@app.route('/api/candidates/<int:id>/status', methods=['PUT'])
def update_candidate_status(id):
    status = request.json.get('status')
    cur = mysql.connection.cursor()
    cur.execute("UPDATE candidates SET status = %s WHERE id = %s", (status, id))
    mysql.connection.commit()
    cur.close()
    return jsonify({'message': f'Status updated to {status}'})


# --- SCHEDULE INTERVIEW ---
@app.route('/api/interviews/<int:candidate_id>', methods=['POST'])
def schedule(candidate_id):
    data = request.json
    interview_date = datetime.strptime(data['interview_date'], '%Y-%m-%dT%H:%M')
    panel = data['panel']
    link = data['link']
    message = data['message']

    cur = mysql.connection.cursor()
    cur.execute("SELECT id FROM interviews WHERE candidate_id = %s", (candidate_id,))
    exists = cur.fetchone()

    if exists:
        cur.execute("""UPDATE interviews SET date=%s, interview_date=%s, panel=%s, link=%s, message=%s 
                       WHERE candidate_id=%s""",
                       (data['interview_date'], interview_date, panel, link, message, candidate_id))
    else:
        cur.execute("""INSERT INTO interviews (candidate_id, date, interview_date, panel, link, message)
                       VALUES (%s, %s, %s, %s, %s, %s)""",
                       (candidate_id, data['interview_date'], interview_date, panel, link, message))
    mysql.connection.commit()
    cur.close()
    return jsonify({'message': 'Interview scheduled successfully'})


# --- CHECK STATUS ---
@app.route('/api/status/<email>', methods=['GET'])
def check_app_status(email):
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name, status FROM candidates WHERE email=%s", [email])
    candidate = cur.fetchone()

    if not candidate:
        return jsonify({'error': 'Candidate not found'}), 404

    candidate_id, name, status = candidate
    cur.execute("SELECT interview_date, panel, link, message FROM interviews WHERE candidate_id=%s", [candidate_id])
    interview = cur.fetchone()
    cur.close()

    interview_data = None
    if interview:
        try:
            interview_data = {
                'interview_date': interview[0].strftime('%Y-%m-%d %H:%M'),
                'panel': interview[1],
                'link': interview[2],
                'message': interview[3]
            }
        except:
            interview_data = {}

    return jsonify({
        'name': name,
        'status': status,
        'interview': interview_data
    })


# --- GET RESUME FILE ---
@app.route('/api/resume/<path:filename>', methods=['GET'])
def download_resume(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

import requests

# Function to get leave data from leave_mng service
def get_leave_data():
    response = requests.get('http://leave_mng:5001/api/leave')  # Use the service name and port
    if response.status_code == 200:
        return response.json()  # Assuming response contains JSON data
    else:
        return {"error": "Failed to fetch leave data"}

# Example of calling the function in your route
@app.route('/leave-data', methods=['GET'])
def leave_data():
    leave = get_leave_data()
    return jsonify(leave)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)