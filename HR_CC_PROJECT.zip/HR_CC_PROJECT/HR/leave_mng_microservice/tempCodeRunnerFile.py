    for label in type_map.values():
        summary