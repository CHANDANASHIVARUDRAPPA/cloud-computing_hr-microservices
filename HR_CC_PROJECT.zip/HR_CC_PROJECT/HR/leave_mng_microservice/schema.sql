-- Create the database
CREATE DATABASE IF NOT EXISTS faculty_db;
USE faculty_db;

-- Faculty table with leave columns
CREATE TABLE IF NOT EXISTS Faculty (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    casual_leaves INT DEFAULT 10,
    sick_leaves INT DEFAULT 10,
    no_pay_leaves INT DEFAULT 0
);

-- LeaveRequest table
CREATE TABLE IF NOT EXISTS LeaveRequest (
    id INT AUTO_INCREMENT PRIMARY KEY,
    faculty_id INT,
    leave_type VARCHAR(50),
    start_date VARCHAR(10),
    end_date VARCHAR(10),
    reason TEXT,
    status VARCHAR(20) DEFAULT 'Pending',
    FOREIGN KEY (faculty_id) REFERENCES Faculty(id)
);

-- Admin table
CREATE TABLE IF NOT EXISTS Admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE,
    password VARCHAR(100)
);

ALTER TABLE Faculty
ADD COLUMN earned_leaves FLOAT DEFAULT 0,
ADD COLUMN sick_leaves INT DEFAULT 12,
ADD COLUMN casual_leaves INT DEFAULT 12,
ADD COLUMN no_pay_leaves INT DEFAULT 0;

ALTER TABLE Faculty ADD COLUMN gender VARCHAR(20) DEFAULT 'Not Specified';

ALTER TABLE Faculty 
ADD COLUMN earned_leaves INT DEFAULT 0,
ADD COLUMN maternity_leaves INT DEFAULT 180,
ADD COLUMN paternity_leaves INT DEFAULT 15,
ADD COLUMN academic_leaves INT DEFAULT 0;


ALTER TABLE LeaveRequest
MODIFY start_date DATE,
MODIFY end_date DATE;


ALTER TABLE LeaveRequest 
ADD COLUMN paid_days INT DEFAULT 0,
ADD COLUMN unpaid_days INT DEFAULT 0;

ALTER TABLE Faculty 
MODIFY casual_leaves INT DEFAULT 8,
MODIFY sick_leaves INT DEFAULT 8,
MODIFY earned_leaves INT DEFAULT 10,
MODIFY no_pay_leaves INT DEFAULT 0,
MODIFY maternity_leaves INT DEFAULT 180,
MODIFY paternity_leaves INT DEFAULT 15,
MODIFY academic_leaves INT DEFAULT 20;

