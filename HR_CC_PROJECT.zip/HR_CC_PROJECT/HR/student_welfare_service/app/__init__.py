import os
from flask import Flask
from flask_mysqldb import MySQL
from dotenv import load_dotenv
from app.routes import register_routes
import os
from dotenv import load_dotenv

load_dotenv()
SQLALCHEMY_DATABASE_URI = os.getenv('DB_URI')

mysql = MySQL()

def create_app():
    load_dotenv()  # Load from .env file

    app = Flask(__name__, static_url_path='/static')
    app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'fallback_key')

    # These will now be injected via environment variables in Compose:
    app.config['MYSQL_USER']     = os.environ['MYSQL_USER']
    app.config['MYSQL_PASSWORD'] = os.environ['MYSQL_PASSWORD']
    app.config['MYSQL_HOST']     = os.environ.get('MYSQL_HOST', 'db')
    app.config['MYSQL_DB']       = os.environ['MYSQL_DB']


    mysql.init_app(app)

    register_routes(app, mysql)

    return app


# This should be in your main entry script, not in the function
if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
