CREATE TABLE admin_details (
  id INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO admin_details (username, password) VALUES
  ('admin1', 'adminpass'),
  ('superadmin', 'super123'),
  ('head_hr', 'hrpass'),
  ('director', 'dir2025');

CREATE TABLE IF NOT EXISTS Faculty (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  gender VARCHAR(20) DEFAULT 'Not Specified',
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(100) NOT NULL,
  casual_leaves INT DEFAULT 8,
  sick_leaves INT DEFAULT 8,
  earned_leaves INT DEFAULT 10,
  no_pay_leaves INT DEFAULT 0,
  maternity_leaves INT DEFAULT 180,
  paternity_leaves INT DEFAULT 15,
  academic_leaves INT DEFAULT 20
);

INSERT INTO Faculty (name, email, gender, username, password) VALUES
  ('Dr. Anjali Rao', 'anjali.rao@univ.edu', 'Female', 'anjalirao', 'securePass123'),
  ('Prof. Ramesh Kumar', 'ramesh.kumar@univ.edu', 'Male', 'rameshk', 'passRamesh2024'),
  ('Dr. Meera Shah', 'meera.shah@univ.edu', 'Female', 'meerashah', 'meeraSecure!'),
  ('Prof. Arvind Nair', 'arvind.nair@univ.edu', 'Male', 'arvindn', 'nairArvind99'),
  ('Dr. Kavita Iyer', 'kavita.iyer@univ.edu', 'Female', 'kavitai', 'iyerKavita!45');

DROP TABLE IF EXISTS faculty_exits;

CREATE TABLE faculty_exits (
  id INT NOT NULL AUTO_INCREMENT,
  faculty_name VARCHAR(100) NOT NULL,
  exit_date DATE NOT NULL,
  reason VARCHAR(255) DEFAULT NULL,
  department VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (id)
);

INSERT INTO faculty_exits (faculty_name, exit_date, reason, department) VALUES
  ('Anna', '2025-04-11', 'Higher Education or Research Opportunities', 'science'),
  ('john', '2025-04-30', 'Higher Education or Research Opportunities', 'cse'),
  ('John Doe', '2025-04-08', 'Higher Education or Research Opportunities', 'Science'),
  ('George Smith', '2025-04-23', 'Better Compensation and Benefits Package', 'cse'),
  ('Jane Smith', '2025-05-08', 'Relocation Due to Personal or Family Reasons', 'ece'),
  ('Harris', '2025-05-30', 'Workload Imbalance and Burnout', 'ece'),
  ('Priya', '2025-04-23', 'Higher Education or Research Opportunities', 'Science'),
  ('Raju', '2025-06-27', 'Limited Access to Resources or Infrastructure', 'Science'),
  ('Esh', '2025-04-23', 'Administrative or Institutional Challenges', 'Science'),
  ('ava', '2025-04-16', 'Lack of Career Progression or Promotion Opportunities', 'cse'),
  ('abc', '2025-07-10', 'Differences in Vision or Academic Philosophy', 'ece'),
  ('Prof. Ramesh Kumar', '2025-04-25', 'Desire to Work in a More Research-Oriented Environment', 'science');

DROP TABLE IF EXISTS faculty_feedback;

CREATE TABLE faculty_feedback (
  id INT NOT NULL AUTO_INCREMENT,
  faculty_name VARCHAR(100) NOT NULL,
  department VARCHAR(100) DEFAULT NULL,
  resignation_letter LONGBLOB DEFAULT NULL,
  reason TEXT DEFAULT NULL,
  PRIMARY KEY (id)
);
